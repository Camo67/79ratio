import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Phone, Mail, MapPin, Clock, MessageSquare, Calendar, Headphones } from "lucide-react"

const contactMethods = [
  {
    icon: Phone,
    title: "Call Us",
    description: "Speak directly with our IT experts",
    contact: "(630) 394-2700",
    availability: "Mon-Fri 8AM-6PM EST",
  },
  {
    icon: Mail,
    title: "Email Us",
    description: "Send us your questions anytime",
    contact: "info@79ratio.com",
    availability: "24/7 - We respond within 2 hours",
  },
  {
    icon: MessageSquare,
    title: "Live Chat",
    description: "Get instant answers to your questions",
    contact: "Available on our website",
    availability: "Mon-Fri 9AM-5PM EST",
  },
  {
    icon: Headphones,
    title: "Emergency Support",
    description: "24/7 support for existing clients",
    contact: "(630) 394-2700",
    availability: "24/7/365 for emergencies",
  },
]

const services = [
  "IT Assessment & Consultation",
  "24/7 Monitoring Setup",
  "Cybersecurity Evaluation",
  "Cloud Migration Planning",
  "Backup & Recovery Solutions",
  "Help Desk Support",
]

export default function ContactPage() {
  return (
    <main className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat animate-slow-drift"
          style={{ backgroundImage: "url(/contact-bg.jpeg)" }}
        />

        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-black/85 via-black/75 to-black/85" />

        {/* Floating Elements Animation */}
        <div className="absolute inset-0">
          <div
            className="absolute top-1/4 left-1/4 w-2 h-2 bg-cyan-400 rounded-full animate-float"
            style={{ animationDelay: "0s" }}
          />
          <div
            className="absolute top-1/3 right-1/3 w-1 h-1 bg-primary rounded-full animate-float-slow"
            style={{ animationDelay: "2s" }}
          />
          <div
            className="absolute bottom-1/4 left-1/3 w-3 h-3 bg-cyan-300/60 rounded-full animate-float"
            style={{ animationDelay: "4s" }}
          />
          <div
            className="absolute top-1/2 right-1/4 w-1.5 h-1.5 bg-primary/80 rounded-full animate-float-slow"
            style={{ animationDelay: "1s" }}
          />
          <div
            className="absolute bottom-1/3 right-1/2 w-2 h-2 bg-cyan-400/70 rounded-full animate-float"
            style={{ animationDelay: "3s" }}
          />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-6">
            <Badge className="mb-4 bg-primary/20 text-white border-primary/30">Let's Connect</Badge>
            <h1 className="text-4xl lg:text-6xl font-bold text-white leading-tight text-balance">
              Start a <span className="text-primary">Conversation</span>
            </h1>
            <p className="text-xl text-gray-200 max-w-3xl mx-auto leading-relaxed text-pretty">
              Every great partnership begins with a conversation. Whether you're facing a specific challenge or
              exploring new possibilities, we're here to listen and help you find the right path forward.
            </p>
            <div className="bg-black/40 backdrop-blur-sm p-6 rounded-lg border border-primary/20 max-w-2xl mx-auto">
              <p className="text-lg text-gray-100 italic">
                "We believe the best solutions come from understanding your story first."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Methods */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground text-balance">Connect Your Way</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Choose the way that feels right for you. Whether you prefer a quick call, detailed email, or live chat,
              we're ready to connect on your terms.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {contactMethods.map((method, index) => {
              const IconComponent = method.icon
              return (
                <Card key={index} className="text-center border-border bg-card hover:shadow-lg transition-shadow">
                  <CardHeader className="space-y-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto">
                      <IconComponent className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg text-white">{method.title}</CardTitle>
                      <CardDescription className="text-gray-200">{method.description}</CardDescription>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="font-semibold text-primary">{method.contact}</div>
                    <div className="text-sm text-gray-300">{method.availability}</div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Contact Form & Info */}
      <section className="py-20 bg-muted/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-2xl text-white">Tell Us Your Story</CardTitle>
                <CardDescription className="text-gray-200">
                  Share what's on your mind. Whether it's a specific challenge, a big idea, or just a question — we're
                  here to listen and help you find the right path forward.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <form className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input id="firstName" placeholder="John" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input id="lastName" placeholder="Doe" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" placeholder="john@company.com" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="company">Company</Label>
                    <Input id="company" placeholder="Your Company Name" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input id="phone" type="tel" placeholder="(630) 394-2700" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="service">What's on your mind?</Label>
                    <select
                      id="service"
                      className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground"
                    >
                      <option value="">Select a topic...</option>
                      {services.map((service, index) => (
                        <option key={index} value={service}>
                          {service}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Your Message</Label>
                    <Textarea
                      id="message"
                      placeholder="Tell us about your challenges, goals, or questions. The more context you share, the better we can help..."
                      className="min-h-[120px]"
                    />
                  </div>

                  <Button type="submit" className="w-full">
                    Start the Conversation
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Company Info */}
            <div className="space-y-8">
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-xl text-white flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-primary" />
                    Find Us Here
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="font-semibold text-white">79Ratio Headquarters</div>
                    <div className="text-gray-200">
                      25 S Grove Ave Ste 501
                      <br />
                      Elgin, Illinois 60120
                      <br />
                      United States
                      <br />
                      <br />
                      <strong>Phone: (630) 394-2700</strong>
                    </div>
                  </div>
                  <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                    <div className="text-muted-foreground">Interactive Map Coming Soon</div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-xl text-white flex items-center gap-2">
                    <Clock className="w-5 h-5 text-primary" />
                    When We're Available
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-200">Monday - Friday</span>
                    <span className="font-medium text-white">8:00 AM - 6:00 PM EST</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-200">Saturday</span>
                    <span className="font-medium text-white">9:00 AM - 2:00 PM EST</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-200">Sunday</span>
                    <span className="font-medium text-white">Emergency Support Only</span>
                  </div>
                  <div className="pt-2 border-t border-border">
                    <div className="flex justify-between">
                      <span className="text-gray-200">Emergency Support</span>
                      <span className="font-medium text-primary">24/7/365</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-xl text-white flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-primary" />
                    Let's Meet
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-200">
                    Ready to explore what's possible? Let's schedule a conversation where we can learn about your goals
                    and share how we might help you achieve them.
                  </p>
                  <Button className="w-full">Schedule a Conversation</Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-background">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground text-balance">Questions We Often Hear</h2>
            <p className="text-xl text-muted-foreground text-pretty">
              Here are some of the questions that come up most often in our conversations with new clients.
            </p>
          </div>

          <div className="space-y-6">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-lg text-white">
                  How quickly can you respond when something goes wrong?
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-200">
                  We know that when your systems are down, every minute matters. That's why we monitor our clients
                  24/7/365 and respond to critical issues in under 5 minutes. For new conversations, we get back to you
                  within 2 hours during business hours — because we believe quick responses show respect for your time.
                </p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-lg text-white">Do you work with businesses like ours?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-200">
                  We work with businesses of all sizes — from solo practices to large organizations. What matters most
                  to us isn't your size, but your commitment to serving your clients well. We tailor our approach to fit
                  your specific needs and budget, because we believe great technology should be accessible to every
                  business.
                </p>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-lg text-white">What makes you different from other IT companies?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-200">
                  We listen first, then build solutions around your actual needs — not what we think you should need.
                  Our team has deep experience in law, healthcare, nonprofits, and manufacturing, so we understand the
                  unique challenges you face. Most importantly, we treat your success as our own mission.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
