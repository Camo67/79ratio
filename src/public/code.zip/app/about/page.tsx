import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Target, Users, Award, ArrowRight } from "lucide-react"

const companyValues = [
  {
    icon: Target,
    title: "Precision",
    description:
      "We deliver technology solutions with meticulous attention to detail, ensuring every system operates flawlessly and meets exact specifications.",
  },
  {
    icon: Users,
    title: "Sustainability",
    description:
      "Our solutions are built for longevity, focusing on sustainable practices that reduce environmental impact while maximizing long-term value.",
  },
  {
    icon: Award,
    title: "Excellence",
    description:
      "We maintain the highest standards in everything we do, from initial consultation to ongoing support, delivering exceptional results consistently.",
  },
]

const teamMembers = [
  {
    name: "David Chen",
    role: "Chief Executive Officer",
    description:
      "With over 15 years in enterprise technology, David leads Ratio79's strategic vision and client relationships.",
    expertise: ["Strategic Planning", "Enterprise Solutions", "Client Relations"],
  },
  {
    name: "Sarah Mitchell",
    role: "Chief Technology Officer",
    description:
      "Sarah brings deep technical expertise in cybersecurity and infrastructure, ensuring our solutions meet the highest standards.",
    expertise: ["Cybersecurity", "Infrastructure Design", "Compliance"],
  },
  {
    name: "Michael Rodriguez",
    role: "Director of Operations",
    description:
      "Michael oversees service delivery and ensures our clients receive consistent, high-quality support across all touchpoints.",
    expertise: ["Service Delivery", "Process Optimization", "Quality Assurance"],
  },
  {
    name: "Jennifer Park",
    role: "Director of Business Development",
    description:
      "Jennifer focuses on understanding client needs and developing tailored solutions that drive business growth.",
    expertise: ["Business Analysis", "Solution Design", "Client Success"],
  },
]

const milestones = [
  { year: "2018", title: "Company Founded", description: "Established with a vision to transform business technology" },
  {
    year: "2020",
    title: "Industry Recognition",
    description: "Received certification as a leading IT services provider",
  },
  {
    year: "2022",
    title: "Expansion",
    description: "Expanded services to include comprehensive cybersecurity solutions",
  },
  {
    year: "2024",
    title: "Innovation Leader",
    description: "Recognized as an innovation leader in business automation",
  },
]

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="py-20 px-4 bg-gradient-to-br from-background to-card">
          <div className="container mx-auto max-w-4xl text-center">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">About Ratio79</Badge>
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
              Where Technology Meets <span className="text-primary">Purpose</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 text-pretty max-w-2xl mx-auto">
              Founded on the principles of Precision, Sustainability, and Excellence, Ratio79 transforms how businesses
              leverage technology to achieve their most ambitious goals.
            </p>
          </div>
        </section>

        {/* Company Story */}
        <section className="py-20 px-4">
          <div className="container mx-auto max-w-4xl">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">Our Story</h2>
              <div className="prose prose-lg max-w-none text-muted-foreground">
                <p className="text-lg leading-relaxed mb-6">
                  Ratio79 was born from a simple observation: businesses deserve technology partners who understand that
                  every system, every solution, and every interaction should reflect the highest standards of precision
                  and care.
                </p>
                <p className="text-lg leading-relaxed mb-6">
                  Our founders recognized that the technology landscape was filled with providers who focused on quick
                  fixes rather than sustainable solutions. We set out to change that narrative, building a company that
                  would approach every challenge with the meticulous attention to detail that our clients' missions
                  deserve.
                </p>
                <p className="text-lg leading-relaxed">
                  Today, we serve businesses across legal, healthcare, nonprofit, and manufacturing sectors, each with
                  unique requirements and uncompromising standards. Our commitment to precision, sustainability, and
                  excellence guides every decision we make and every solution we deliver.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Company Values */}
        <section className="py-20 px-4 bg-card">
          <div className="container mx-auto max-w-7xl">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">Our Core Values</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
                The principles that guide every decision, every solution, and every client relationship.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {companyValues.map((value, index) => (
                <Card key={index} className="text-center hover:border-primary/50 transition-all duration-300">
                  <CardHeader>
                    <div className="w-16 h-16 bg-primary/10 rounded-xl flex items-center justify-center mx-auto mb-6">
                      <value.icon className="w-8 h-8 text-primary" />
                    </div>
                    <CardTitle className="text-2xl mb-4">{value.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-muted-foreground leading-relaxed text-base">
                      {value.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Timeline */}
        <section className="py-20 px-4">
          <div className="container mx-auto max-w-4xl">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">Our Journey</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
                Key milestones in our mission to transform business technology.
              </p>
            </div>

            <div className="space-y-8">
              {milestones.map((milestone, index) => (
                <div key={index} className="flex items-start space-x-6">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-bold">
                      {milestone.year.slice(-2)}
                    </div>
                  </div>
                  <div className="flex-grow">
                    <div className="flex items-center space-x-4 mb-2">
                      <h3 className="text-xl font-semibold">{milestone.title}</h3>
                      <Badge variant="outline" className="text-xs">
                        {milestone.year}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground leading-relaxed">{milestone.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-20 px-4 bg-card">
          <div className="container mx-auto max-w-7xl">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">Leadership Team</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
                Meet the experts who bring decades of experience and unwavering commitment to your success.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {teamMembers.map((member, index) => (
                <Card key={index} className="hover:border-primary/50 transition-all duration-300 fade-in-up">
                  <CardHeader>
                    <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Users className="w-8 h-8 text-primary" />
                    </div>
                    <CardTitle className="text-xl text-center">{member.name}</CardTitle>
                    <CardDescription className="text-primary text-center font-medium">{member.role}</CardDescription>
                  </CardHeader>
                  <CardContent className="text-center">
                    <p className="text-muted-foreground mb-4 leading-relaxed">{member.description}</p>
                    <div className="flex flex-wrap justify-center gap-2">
                      {member.expertise.map((skill, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-4">
          <div className="container mx-auto max-w-4xl text-center">
            <div className="bg-gradient-to-r from-primary/10 to-primary/5 rounded-2xl p-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">Ready to Experience the Difference?</h2>
              <p className="text-xl text-muted-foreground mb-8 text-pretty max-w-2xl mx-auto">
                Discover how our commitment to precision, sustainability, and excellence can transform your technology
                infrastructure.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="text-lg px-8 py-6">
                  Schedule a Consultation
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <Button variant="outline" size="lg" className="text-lg px-8 py-6 bg-transparent">
                  Learn About Our Process
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
