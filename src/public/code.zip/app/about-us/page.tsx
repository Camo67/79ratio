import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { MapPin, Phone, Mail, Clock, Send, Calendar } from "lucide-react"

const contactMethods = [
  {
    icon: Phone,
    title: "Phone",
    details: "(630) 394-2700",
    description: "Speak directly with our experts",
  },
  {
    icon: Mail,
    title: "Email",
    details: "info@ratio79.com",
    description: "Send us your questions anytime",
  },
  {
    icon: MapPin,
    title: "Office",
    details: "25 S Grove Ave Ste 501\nElgin, Illinois, 60120",
    description: "Visit our headquarters",
  },
  {
    icon: Clock,
    title: "Hours",
    details: "Mon-Fri: 8:00 AM - 6:00 PM\nSat: 9:00 AM - 2:00 PM",
    description: "When we're available",
  },
]

const supportOptions = [
  {
    title: "General Inquiries",
    description: "Questions about our services or getting started",
    action: "Contact Sales",
  },
  {
    title: "Technical Support",
    description: "Existing clients needing technical assistance",
    action: "Get Support",
  },
  {
    title: "Emergency Support",
    description: "Critical issues requiring immediate attention",
    action: "Emergency Line",
  },
]

export default function ContactPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="py-20 px-4 bg-gradient-to-br from-background to-card">
          <div className="container mx-auto max-w-4xl text-center">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">Get in Touch</Badge>
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-balance">
              Let's Discuss Your <span className="text-primary">Technology Needs</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 text-pretty max-w-2xl mx-auto">
              Ready to transform your technology infrastructure? Our experts are here to help you find the perfect
              solution for your business.
            </p>
          </div>
        </section>

        {/* Contact Methods */}
        <section className="py-20 px-4">
          <div className="container mx-auto max-w-7xl">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 text-balance">How to Reach Us</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
                Multiple ways to connect with our team and get the support you need.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {contactMethods.map((method, index) => (
                <Card key={index} className="text-center hover:border-primary/50 transition-all duration-300">
                  <CardHeader>
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <method.icon className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle className="text-lg">{method.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="font-medium text-foreground mb-2 whitespace-pre-line">{method.details}</p>
                    <CardDescription className="text-sm">{method.description}</CardDescription>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Form and Support Options */}
        <section className="py-20 px-4 bg-card">
          <div className="container mx-auto max-w-7xl">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Contact Form */}
              <div>
                <h2 className="text-3xl font-bold mb-6">Send Us a Message</h2>
                <p className="text-muted-foreground mb-8 leading-relaxed">
                  Fill out the form below and we'll get back to you within 24 hours. For urgent matters, please call us
                  directly.
                </p>

                <form className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="firstName" className="block text-sm font-medium mb-2">
                        First Name *
                      </label>
                      <Input
                        id="firstName"
                        placeholder="John"
                        className="focus:ring-primary focus:border-primary"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="lastName" className="block text-sm font-medium mb-2">
                        Last Name *
                      </label>
                      <Input
                        id="lastName"
                        placeholder="Doe"
                        className="focus:ring-primary focus:border-primary"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-2">
                      Email Address *
                    </label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="john@company.com"
                      className="focus:ring-primary focus:border-primary"
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="company" className="block text-sm font-medium mb-2">
                      Company Name
                    </label>
                    <Input
                      id="company"
                      placeholder="Your Company"
                      className="focus:ring-primary focus:border-primary"
                    />
                  </div>

                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium mb-2">
                      Phone Number
                    </label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="(555) 123-4567"
                      className="focus:ring-primary focus:border-primary"
                    />
                  </div>

                  <div>
                    <label htmlFor="subject" className="block text-sm font-medium mb-2">
                      Subject *
                    </label>
                    <Input
                      id="subject"
                      placeholder="How can we help you?"
                      className="focus:ring-primary focus:border-primary"
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-medium mb-2">
                      Message *
                    </label>
                    <Textarea
                      id="message"
                      placeholder="Tell us about your technology needs and challenges..."
                      rows={6}
                      className="focus:ring-primary focus:border-primary"
                      required
                    />
                  </div>

                  <Button type="submit" size="lg" className="w-full">
                    Send Message
                    <Send className="ml-2 w-4 h-4" />
                  </Button>
                </form>
              </div>

              {/* Support Options */}
              <div>
                <h2 className="text-3xl font-bold mb-6">Support Options</h2>
                <p className="text-muted-foreground mb-8 leading-relaxed">
                  Choose the support option that best fits your needs. Our team is ready to assist you.
                </p>

                <div className="space-y-6">
                  {supportOptions.map((option, index) => (
                    <Card key={index} className="hover:border-primary/50 transition-all duration-300">
                      <CardHeader>
                        <CardTitle className="text-lg">{option.title}</CardTitle>
                        <CardDescription>{option.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Button variant="outline" className="w-full bg-transparent">
                          {option.action}
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Calendar Booking */}
                <Card className="mt-8 bg-gradient-to-r from-primary/5 to-primary/10 border-primary/20">
                  <CardHeader className="text-center">
                    <Calendar className="w-12 h-12 text-primary mx-auto mb-4" />
                    <CardTitle className="text-xl">Schedule a Consultation</CardTitle>
                    <CardDescription>
                      Book a free 30-minute consultation to discuss your technology needs
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button size="lg" className="w-full">
                      Book Consultation
                    </Button>
                  </CardContent>
                </Card>

                {/* Emergency Contact */}
                <Card className="mt-6 border-destructive/20 bg-destructive/5">
                  <CardContent className="p-6 text-center">
                    <h3 className="font-semibold text-destructive mb-2">Emergency Support</h3>
                    <p className="text-sm text-muted-foreground mb-4">For critical issues outside business hours</p>
                    <Button variant="destructive" size="sm">
                      Call Emergency Line
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Map Section */}
        <section className="py-20 px-4">
          <div className="container mx-auto max-w-4xl text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">Visit Our Office</h2>
            <p className="text-xl text-muted-foreground mb-8 text-pretty max-w-2xl mx-auto">
              Located in Elgin, Illinois, we're easily accessible and always happy to meet in person.
            </p>

            <Card className="overflow-hidden">
              <CardContent className="p-0">
                <div className="bg-muted h-64 flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="w-12 h-12 text-primary mx-auto mb-4" />
                    <p className="font-medium">25 S Grove Ave Ste 501</p>
                    <p className="text-muted-foreground">Elgin, Illinois, 60120</p>
                    <Button variant="outline" className="mt-4 bg-transparent">
                      Get Directions
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}
