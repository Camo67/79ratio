import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight, Palette, Eye, Zap } from "lucide-react"

export default function DesignAccessibilityPage() {
  const services = [
    {
      icon: Palette,
      title: "UX/UI Design",
      description: "Human-centered design processes",
      benefits: ["40% engagement increase", "Reduced bounce rates", "Higher conversion"],
      details: "User research, prototyping, and usability testing.",
    },
    {
      icon: Eye,
      title: "Accessibility Audits",
      description: "Comprehensive WCAG 2.1 compliance",
      benefits: ["Legal compliance", "Expanded user base", "Improved SEO"],
      details: "Screen reader compatibility and keyboard navigation assessment.",
    },
    {
      icon: Palette,
      title: "Branding & Visual Identity",
      description: "Cohesive and professional brands",
      benefits: ["Stronger recognition", "Consistent messaging", "Professional image"],
      details: "Logo design, typography, and collateral development.",
    },
    {
      icon: Zap,
      title: "Responsive Design",
      description: "Mobile-first, cross-platform interfaces",
      benefits: ["Better mobile experience", "Improved SEO", "Increased conversions"],
      details: "Optimized for diverse devices and screen sizes.",
    },
  ]

  const features = [
    "Screen reader support",
    "Keyboard accessibility",
    "Color contrast optimization",
    "Inclusive design from discovery to deployment",
    "Continuous support and improvements",
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/web-design-accessibility-user-interface.jpg"
            alt="Design & Accessibility Background"
            fill
            className="object-cover animate-slow-drift"
          />
          <div className="absolute inset-0 bg-black/70" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-8">
            <Image
              src="/79ratio-logo.webp"
              alt="79Ratio Logo"
              width={200}
              height={67}
              className="mx-auto mb-8"
              priority
            />
          </div>

          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">Design & Accessibility</h1>
          <p className="text-xl text-gray-300 mb-4 max-w-3xl mx-auto">Inclusive Design That Reaches Everyone</p>
          <p className="text-lg text-gray-400 mb-8 max-w-3xl mx-auto">
            We blend creativity with accessibility, crafting user-centered digital experiences that engage and empower
            all users.
          </p>
          <Button size="lg" className="bg-primary hover:bg-primary/90">
            Schedule a Call
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>

      {/* Services Grid */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/design-interface-creativity.jpg"
            alt="Services Background"
            fill
            className="object-cover animate-slow-drift"
          />
          <div className="absolute inset-0 bg-black/60" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Our Services</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <Card
                key={index}
                className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300"
              >
                <CardContent className="p-8">
                  <service.icon className="w-12 h-12 text-primary mb-4" />
                  <h3 className="text-2xl font-semibold text-white mb-2">{service.title}</h3>
                  <p className="text-gray-300 mb-4">{service.description}</p>
                  <p className="text-gray-400 text-sm mb-6">{service.details}</p>
                  <div className="space-y-2">
                    <p className="text-sm font-semibold text-primary">Benefits:</p>
                    <ul className="space-y-1">
                      {service.benefits.map((benefit, idx) => (
                        <li key={idx} className="text-sm text-gray-300 flex items-center">
                          <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2" />
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Accessibility Features */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-black/40" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Accessibility Features & Process</h2>
              <p className="text-lg text-gray-300 mb-8">
                Our solutions incorporate comprehensive accessibility standards from discovery to deployment with
                continuous support for improvements.
              </p>
              <ul className="space-y-4">
                {features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-6 w-6 rounded-md bg-primary text-black">
                        <span className="text-sm font-semibold">✓</span>
                      </div>
                    </div>
                    <p className="ml-4 text-gray-300">{feature}</p>
                  </li>
                ))}
              </ul>
            </div>

            <div className="grid grid-cols-2 gap-6">
              {[
                { metric: "40%", label: "Engagement Increase" },
                { metric: "WCAG 2.1", label: "AA Compliant" },
                { metric: "100%", label: "Keyboard Nav" },
                { metric: "24/7", label: "Support" },
              ].map((stat, index) => (
                <Card key={index} className="bg-white/10 backdrop-blur-sm border-white/20 text-center">
                  <CardContent className="p-6">
                    <div className="text-2xl font-bold text-primary mb-2">{stat.metric}</div>
                    <div className="text-sm text-gray-300">{stat.label}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-transparent" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Build Accessible Digital Experiences</h2>
          <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Let's create designs that work for everyone while maximizing your business impact.
          </p>
          <Button size="lg" className="bg-primary hover:bg-primary/90">
            Schedule a Consultation
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>
    </div>
  )
}
