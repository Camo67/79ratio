import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight, Cloud, Database, Network, Zap } from "lucide-react"

export default function DigitalInfrastructurePage() {
  const services = [
    {
      icon: Cloud,
      title: "Cloud Infrastructure",
      description: "Scalable, secure cloud solutions that grow with your business needs",
      benefits: ["99.9% uptime", "50% cost reduction", "Instant scalability"],
      details:
        "Deployed on major platforms like AWS, Azure, and Google Cloud with hybrid architectures and auto-scaling to cut costs and increase agility.",
    },
    {
      icon: Database,
      title: "Virtualization Solutions",
      description: "Maximize hardware efficiency through enterprise-grade virtualization",
      benefits: ["70% hardware savings", "Improved disaster recovery", "Enhanced security"],
      details: "Including VMware vSphere, Hyper-V environments, and container orchestration.",
    },
    {
      icon: Network,
      title: "Network Architecture",
      description: "Secure, high-performance networks with advanced optimization",
      benefits: ["Enhanced performance", "Reduced latency", "Improved security"],
      details: "Design and implement secure networks with SD-WAN, bandwidth optimization, and redundancy measures.",
    },
    {
      icon: Zap,
      title: "System Integration",
      description: "Unify disparate systems through comprehensive integration",
      benefits: ["Streamlined operations", "Data consistency", "Reduced manual work"],
      details: "API development, legacy modernization, and workflow automation.",
    },
  ]

  const process = [
    { step: "1", title: "Assessment", description: "Evaluate your current infrastructure" },
    { step: "2", title: "Design", description: "Create a tailored solution architecture" },
    { step: "3", title: "Implementation", description: "Deploy with minimal disruption" },
    { step: "4", title: "Testing", description: "Ensure performance and reliability" },
    { step: "5", title: "Support", description: "Ongoing maintenance and optimization" },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/digital-infrastructure-technology-network.jpg"
            alt="Digital Infrastructure Background"
            fill
            className="object-cover animate-slow-drift"
          />
          <div className="absolute inset-0 bg-black/70" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-8">
            <Image
              src="/79ratio-logo.webp"
              alt="79Ratio Logo"
              width={200}
              height={67}
              className="mx-auto mb-8"
              priority
            />
          </div>

          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">Digital Infrastructure Solutions</h1>
          <p className="text-xl text-gray-300 mb-4 max-w-3xl mx-auto">Digital Systems That Power Your Success</p>
          <p className="text-lg text-gray-400 mb-8 max-w-3xl mx-auto">
            Unleash precision and power with robust, programmable, and highly accurate technology that ensures seamless
            integration and future-proof scalability.
          </p>
          <Button size="lg" className="bg-primary hover:bg-primary/90">
            Schedule a Call
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>

      {/* Services Grid */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/cloud-computing-infrastructure.jpg"
            alt="Services Background"
            fill
            className="object-cover animate-slow-drift"
          />
          <div className="absolute inset-0 bg-black/60" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Our Services</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <Card
                key={index}
                className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300"
              >
                <CardContent className="p-8">
                  <service.icon className="w-12 h-12 text-primary mb-4" />
                  <h3 className="text-2xl font-semibold text-white mb-2">{service.title}</h3>
                  <p className="text-gray-300 mb-4">{service.description}</p>
                  <p className="text-gray-400 text-sm mb-6">{service.details}</p>
                  <div className="space-y-2">
                    <p className="text-sm font-semibold text-primary">Benefits:</p>
                    <ul className="space-y-1">
                      {service.benefits.map((benefit, idx) => (
                        <li key={idx} className="text-sm text-gray-300 flex items-center">
                          <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2" />
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Implementation Process */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-black/40" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Implementation Process</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              A structured five-step approach ensuring smooth transitions and reliable performance
            </p>
          </div>

          <div className="grid md:grid-cols-5 gap-4">
            {process.map((item, index) => (
              <div key={index} className="text-center">
                <div className="mb-4">
                  <div className="w-12 h-12 bg-primary text-black rounded-full flex items-center justify-center mx-auto text-lg font-bold mb-4">
                    {item.step}
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{item.title}</h3>
                  <p className="text-gray-300 text-sm">{item.description}</p>
                </div>
                {index < process.length - 1 && (
                  <div className="hidden md:block absolute right-0 top-6 transform translate-x-1/2">
                    <ArrowRight className="w-5 h-5 text-primary/50" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-transparent" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Ready to Transform Your Infrastructure?</h2>
          <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Let our experts design and implement the perfect solution for your business.
          </p>
          <Button size="lg" className="bg-primary hover:bg-primary/90">
            Schedule a Consultation
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>
    </div>
  )
}
