import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight, Cloud, Database, RefreshCw, Zap } from "lucide-react"

export default function CloudSolutionsPage() {
  const services = [
    {
      icon: Cloud,
      title: "Cloud Migration",
      description: "Strategic planning and seamless transfer",
      benefits: ["Cost efficiency", "Scalability", "Security"],
      details: "Seamless transfer with minimal downtime and maximum reliability.",
    },
    {
      icon: Database,
      title: "Managed Cloud Hosting",
      description: "24/7 monitoring and management",
      benefits: ["99.9% uptime", "Continuous support", "Cost optimization"],
      details: "High availability solutions with expert management.",
    },
    {
      icon: RefreshCw,
      title: "Disaster Recovery",
      description: "Automated backups and recovery testing",
      benefits: ["Rapid recovery", "Data protection", "Minimal disruption"],
      details: "Resilient business continuity solutions.",
    },
    {
      icon: Zap,
      title: "Cloud Optimization",
      description: "Ongoing tuning and improvement",
      benefits: ["Cost savings", "Resource efficiency", "Better performance"],
      details: "Continuous optimization for peak performance.",
    },
  ]

  const benefits = [
    {
      metric: "50%",
      description: "Reduction in infrastructure costs",
    },
    {
      metric: "Instant",
      description: "Scaling of resources",
    },
    {
      metric: "10x",
      description: "Faster deployment speeds",
    },
    {
      metric: "Global",
      description: "Network and content delivery",
    },
  ]

  const platforms = ["AWS", "Microsoft Azure", "Google Cloud"]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/cloud-computing-technology-network.jpg"
            alt="Cloud Solutions Background"
            fill
            className="object-cover animate-slow-drift"
          />
          <div className="absolute inset-0 bg-black/70" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-8">
            <Image
              src="/79ratio-logo.webp"
              alt="79Ratio Logo"
              width={200}
              height={67}
              className="mx-auto mb-8"
              priority
            />
          </div>

          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">Cloud Solutions</h1>
          <p className="text-xl text-gray-300 mb-4 max-w-3xl mx-auto">Scale Your Business with Cloud Solutions</p>
          <p className="text-lg text-gray-400 mb-8 max-w-3xl mx-auto">
            Leverage scalable, secure cloud technology to drive innovation, flexibility, and cost savings.
          </p>
          <Button size="lg" className="bg-primary hover:bg-primary/90">
            Schedule a Call
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>

      {/* Key Benefits */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-black/40" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Key Benefits</h2>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <Card
                key={index}
                className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300 text-center"
              >
                <CardContent className="p-8">
                  <div className="text-4xl font-bold text-primary mb-3">{benefit.metric}</div>
                  <p className="text-gray-300">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/cloud-infrastructure.png"
            alt="Services Background"
            fill
            className="object-cover animate-slow-drift"
          />
          <div className="absolute inset-0 bg-black/60" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Our Services</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <Card
                key={index}
                className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300"
              >
                <CardContent className="p-8">
                  <service.icon className="w-12 h-12 text-primary mb-4" />
                  <h3 className="text-2xl font-semibold text-white mb-2">{service.title}</h3>
                  <p className="text-gray-300 mb-4">{service.description}</p>
                  <p className="text-gray-400 text-sm mb-6">{service.details}</p>
                  <div className="space-y-2">
                    <p className="text-sm font-semibold text-primary">Benefits:</p>
                    <ul className="space-y-1">
                      {service.benefits.map((benefit, idx) => (
                        <li key={idx} className="text-sm text-gray-300 flex items-center">
                          <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2" />
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Supported Platforms */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-black/40" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Supported Platforms</h2>
            <p className="text-lg text-gray-300">Experts across all major cloud providers with deep specialization</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {platforms.map((platform, index) => (
              <Card
                key={index}
                className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300 text-center"
              >
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold text-primary">{platform}</h3>
                  <p className="text-gray-400 text-sm mt-2">Deep specialization in core services</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Success Story */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/fortune-500-enterprise-cloud-success.jpg"
            alt="Success Background"
            fill
            className="object-cover animate-slow-drift"
          />
          <div className="absolute inset-0 bg-black/70" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-8 md:p-12">
            <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">Fortune 500 Company Success</h3>
            <p className="text-gray-300 text-lg mb-6">
              A Fortune 500 company transformed their infrastructure with our cloud solutions.
            </p>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                { metric: "60%", label: "Cost Reduction" },
                { metric: "3x", label: "Performance Increase" },
                { metric: "99.9%", label: "Uptime Achieved" },
              ].map((item, index) => (
                <div key={index} className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">{item.metric}</div>
                  <p className="text-gray-400">{item.label}</p>
                </div>
              ))}
            </div>
            <p className="text-gray-400 text-sm mt-8">Results achieved in a six-month migration</p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-transparent" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Ready to Move to the Cloud?</h2>
          <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Let our cloud experts guide you through a seamless migration and optimization journey.
          </p>
          <Button size="lg" className="bg-primary hover:bg-primary/90">
            Schedule a Consultation
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>
    </div>
  )
}
