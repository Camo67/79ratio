import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight, Cog, Shield, TrendingUp, CheckCircle } from "lucide-react"

export default function ComplianceOptimizationPage() {
  const services = [
    {
      icon: Cog,
      title: "Business Process Automation",
      description: "Reduce manual effort with workflow automation",
      benefits: ["70% time savings", "Reduced errors", "Improved productivity"],
      details: "Workflow automation, document processing, and system integration.",
    },
    {
      icon: Shield,
      title: "Compliance Management",
      description: "Comprehensive audits and ongoing monitoring",
      benefits: ["Risk reduction", "Audit readiness", "Legal protection"],
      details: "Policy making, risk mitigation, and regulatory alignment.",
    },
    {
      icon: TrendingUp,
      title: "Performance Analytics",
      description: "Actionable insights from your data",
      benefits: ["Data-driven decisions", "Performance gains", "Strategic insights"],
      details: "KPIs, business intelligence, and predictive analytics.",
    },
    {
      icon: Cog,
      title: "Workflow Optimization",
      description: "Accelerate processes while maintaining quality",
      benefits: ["Faster workflows", "Cost savings", "Quality improvement"],
      details: "Identify bottlenecks and implement strategic improvements.",
    },
  ]

  const standards = ["GDPR", "HIPAA", "SOX", "PCI DSS", "ISO 27001", "SOC 2"]

  const process = [
    { step: "Analysis", description: "Deep dive into your processes" },
    { step: "Gap Identification", description: "Identify compliance gaps" },
    { step: "Solution Design", description: "Create tailored solutions" },
    { step: "Implementation", description: "Deploy with precision" },
    { step: "Monitoring", description: "Continuous improvement" },
  ]

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/compliance-business-process-optimization.jpg"
            alt="Compliance Background"
            fill
            className="object-cover animate-slow-drift"
          />
          <div className="absolute inset-0 bg-black/70" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-8">
            <Image
              src="/79ratio-logo.webp"
              alt="79Ratio Logo"
              width={200}
              height={67}
              className="mx-auto mb-8"
              priority
            />
          </div>

          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">Compliance & Optimization Solutions</h1>
          <p className="text-xl text-gray-300 mb-4 max-w-3xl mx-auto">Streamline Operations & Ensure Compliance</p>
          <p className="text-lg text-gray-400 mb-8 max-w-3xl mx-auto">
            Transform your business with intelligent automation and comprehensive compliance solutions that reduce risks
            and promote sustainable growth.
          </p>
          <Button size="lg" className="bg-primary hover:bg-primary/90">
            Schedule a Call
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>

      {/* Services Grid */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/business-process-automation.png"
            alt="Services Background"
            fill
            className="object-cover animate-slow-drift"
          />
          <div className="absolute inset-0 bg-black/60" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Our Services</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <Card
                key={index}
                className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300"
              >
                <CardContent className="p-8">
                  <service.icon className="w-12 h-12 text-primary mb-4" />
                  <h3 className="text-2xl font-semibold text-white mb-2">{service.title}</h3>
                  <p className="text-gray-300 mb-4">{service.description}</p>
                  <p className="text-gray-400 text-sm mb-6">{service.details}</p>
                  <div className="space-y-2">
                    <p className="text-sm font-semibold text-primary">Benefits:</p>
                    <ul className="space-y-1">
                      {service.benefits.map((benefit, idx) => (
                        <li key={idx} className="text-sm text-gray-300 flex items-center">
                          <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2" />
                          {benefit}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Supported Standards */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-black/40" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Supported Standards</h2>
            <p className="text-lg text-gray-300">We ensure compliance with industry-leading standards</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {standards.map((standard, index) => (
              <Card
                key={index}
                className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300"
              >
                <CardContent className="p-6 text-center">
                  <p className="font-semibold text-primary">{standard}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Optimization Process */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-black/40" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">5-Step Optimization Process</h2>
            <p className="text-xl text-gray-300">A proven methodology for continuous improvement and compliance</p>
          </div>

          <div className="grid md:grid-cols-5 gap-4">
            {process.map((item, index) => (
              <div key={index} className="text-center">
                <div className="mb-4">
                  <div className="w-16 h-16 bg-primary text-black rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8" />
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{item.step}</h3>
                  <p className="text-gray-300 text-sm">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Success Story */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/manufacturing-production-success.jpg"
            alt="Success Background"
            fill
            className="object-cover animate-slow-drift"
          />
          <div className="absolute inset-0 bg-black/70" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-8 md:p-12">
            <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">Manufacturing Client Success Story</h3>
            <p className="text-gray-300 text-lg mb-6">
              A manufacturing client achieved remarkable results through our compliance and optimization solutions.
            </p>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                { metric: "60%", label: "Reduction in Processing Time" },
                { metric: "$500K", label: "Annual Savings" },
                { metric: "100%", label: "Compliance Achieved" },
              ].map((item, index) => (
                <div key={index} className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">{item.metric}</div>
                  <p className="text-gray-400">{item.label}</p>
                </div>
              ))}
            </div>
            <p className="text-gray-400 text-sm mt-8">Results achieved within 3 months of implementation</p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-transparent" />
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Optimize Your Operations Today</h2>
          <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Let our experts help you streamline processes and achieve compliance.
          </p>
          <Button size="lg" className="bg-primary hover:bg-primary/90">
            Schedule a Consultation
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>
    </div>
  )
}
