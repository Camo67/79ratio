import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Users, Heart, Lightbulb, Trophy, MapPin, Clock } from "lucide-react"
import Link from "next/link"

const benefits = [
  {
    icon: Heart,
    title: "Health & Wellness",
    description: "Comprehensive health insurance, dental, vision, and wellness programs for you and your family.",
  },
  {
    icon: Lightbulb,
    title: "Continuous Learning",
    description:
      "Professional development budget, conference attendance, and certification support to grow your skills.",
  },
  {
    icon: Users,
    title: "Collaborative Culture",
    description: "Work with a team that values your input, celebrates wins together, and supports each other's growth.",
  },
  {
    icon: Trophy,
    title: "Recognition & Growth",
    description: "Clear career paths, performance bonuses, and opportunities to lead projects that make a real impact.",
  },
]

const openPositions = [
  {
    title: "Senior Network Engineer",
    department: "Infrastructure",
    location: "Cape Town / Remote",
    type: "Full-time",
    description:
      "Join our infrastructure team to design and maintain secure, scalable network solutions for our clients.",
    requirements: [
      "5+ years network engineering experience",
      "Cisco/Juniper certifications preferred",
      "Strong troubleshooting skills",
    ],
  },
  {
    title: "Cybersecurity Analyst",
    department: "Security",
    location: "Johannesburg / Hybrid",
    type: "Full-time",
    description: "Protect our clients from evolving threats while building comprehensive security programs.",
    requirements: [
      "3+ years cybersecurity experience",
      "Security+ or CISSP certification",
      "Incident response experience",
    ],
  },
  {
    title: "Cloud Solutions Specialist",
    department: "Cloud Services",
    location: "Remote",
    type: "Full-time",
    description: "Help businesses transform through cloud adoption with Azure and AWS expertise.",
    requirements: ["Azure/AWS certifications", "Cloud migration experience", "Strong client communication skills"],
  },
]

export default function CareersPage() {
  return (
    <main className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black/90 via-black/80 to-black/90" />
        <div className="absolute inset-0">
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-30"
            style={{ backgroundImage: "url(/team-collaboration-bg.png)" }}
          />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl font-bold text-white leading-tight text-balance">
                Join the Architects of <span className="text-primary">Evolution</span>
              </h1>
              <p className="text-xl text-gray-200 max-w-3xl mx-auto leading-relaxed text-pretty">
                Build a career where you're not just supporting technology, but evolving it. Work where technology and
                human impact meet.
              </p>
            </div>

            <div className="bg-black/40 backdrop-blur-sm p-6 rounded-lg border border-primary/20 max-w-2xl mx-auto">
              <p className="text-lg text-gray-100 italic">
                "If you want to make a real difference — not just write code, but shape experiences — Ratio79 is where
                your work matters."
              </p>
            </div>

            <Button asChild size="lg" className="text-lg px-8">
              <Link href="#positions">View Open Positions</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Culture Section */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground text-balance">Our Culture</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              At Ratio79, we cultivate a culture of growth, innovation, and respect. We seek talented individuals who
              care as much about people as technology.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => {
              const IconComponent = benefit.icon
              return (
                <Card
                  key={index}
                  className="text-center border-border bg-card hover:bg-card/80 transition-all duration-300"
                >
                  <CardHeader className="space-y-4">
                    <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto">
                      <IconComponent className="w-8 h-8 text-primary" />
                    </div>
                    <CardTitle className="text-xl text-white">{benefit.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-gray-200">{benefit.description}</CardDescription>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Open Positions */}
      <section id="positions" className="py-20 bg-muted/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground text-balance">Open Positions</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Join our team of passionate professionals who are shaping the future of business technology.
            </p>
          </div>

          <div className="space-y-6">
            {openPositions.map((position, index) => (
              <Card key={index} className="border-border bg-card hover:shadow-lg transition-all duration-300">
                <CardHeader>
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    <div className="space-y-2">
                      <CardTitle className="text-2xl text-white">{position.title}</CardTitle>
                      <div className="flex flex-wrap gap-2">
                        <Badge variant="secondary">{position.department}</Badge>
                        <Badge variant="outline" className="border-primary text-primary">
                          <MapPin className="w-3 h-3 mr-1" />
                          {position.location}
                        </Badge>
                        <Badge variant="outline" className="border-primary text-primary">
                          <Clock className="w-3 h-3 mr-1" />
                          {position.type}
                        </Badge>
                      </div>
                    </div>
                    <Button asChild>
                      <Link href="/contact">Apply Now</Link>
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-gray-200 leading-relaxed">{position.description}</p>
                  <div>
                    <h4 className="font-medium text-white mb-2">Key Requirements:</h4>
                    <ul className="space-y-1">
                      {position.requirements.map((req, reqIndex) => (
                        <li key={reqIndex} className="text-gray-200 text-sm flex items-center">
                          <div className="w-1.5 h-1.5 bg-primary rounded-full mr-3 flex-shrink-0" />
                          {req}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary to-accent">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-6">
            <h2 className="text-3xl lg:text-4xl font-bold text-primary-foreground text-balance">
              Ready to Shape the Future?
            </h2>
            <p className="text-xl text-primary-foreground/90 text-pretty">
              Don't see the perfect role? We're always interested in connecting with talented individuals who share our
              passion for technology and client success.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" variant="secondary" className="text-lg px-8">
                <Link href="/contact">Send Your Resume</Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="text-lg px-8 border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary bg-transparent"
              >
                <Link href="/team">Meet the Team</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
