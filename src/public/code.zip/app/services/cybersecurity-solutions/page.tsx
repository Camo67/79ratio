import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, Lock, Eye, Users, FileCheck, AlertCircle, Zap, ArrowRight } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function CybersecurityPage() {
  const threats = [
    {
      icon: Shield,
      title: "Ransomware",
      description: "Multi-layered defense to prevent data encryption attacks.",
    },
    {
      icon: AlertCircle,
      title: "Phishing Attacks",
      description: "Advanced email filtering to block malicious attempts.",
    },
    {
      icon: Lock,
      title: "Data Breaches",
      description: "Zero-trust architecture securing sensitive information.",
    },
    {
      icon: Users,
      title: "Insider Threats",
      description: "Behavioral analytics to detect internal risks.",
    },
  ]

  const services = [
    {
      icon: Eye,
      title: "Threat Detection & Response",
      description: "AI-powered 24/7 monitoring and rapid incident response",
      benefits: ["Real-time protection", "Faster reaction", "Damage limitation"],
      details: "Minimize damage with immediate threat detection and expert response.",
    },
    {
      icon: FileCheck,
      title: "Security Assessments",
      description: "Comprehensive security audits and testing",
      benefits: ["Risk identification", "Compliance validation", "Strategic planning"],
      details: "Vulnerability scans, penetration testing, and compliance gap reviews.",
    },
    {
      icon: Lock,
      title: "Data Protection",
      description: "Encryption and access control solutions",
      benefits: ["Data privacy", "Regulatory compliance", "Business continuity"],
      details: "Encryption, access control, DLP, and backup ensure privacy and continuity.",
    },
    {
      icon: Zap,
      title: "Endpoint Security",
      description: "Comprehensive device protection",
      benefits: ["Device security", "Remote work enablement", "Centralized control"],
      details: "Mobile management and remote wiping for complete device protection.",
    },
  ]

  const certifications = ["SOC 2 Type II", "ISO 27001", "HIPAA", "100% Compliance", "Zero Data Breaches"]

  const framework = [
    { step: "Identify", description: "Discover and manage cybersecurity risks" },
    { step: "Protect", description: "Develop defensive strategies and measures" },
    { step: "Detect", description: "Monitor for cybersecurity events" },
    { step: "Respond", description: "Plan and execute incident response" },
    { step: "Recover", description: "Restore normal operations after incidents" },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat animate-slow-drift"
            style={{
              backgroundImage: "url(/contact-bg.jpeg)",
              filter: "brightness(0.15)",
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-br from-black/85 via-black/75 to-black/85" />

          <div className="absolute inset-0">
            <div
              className="absolute top-1/4 left-1/4 w-2 h-2 bg-primary rounded-full animate-float"
              style={{ animationDelay: "0s" }}
            />
            <div
              className="absolute top-1/2 right-1/5 w-1.5 h-1.5 bg-cyan-400 rounded-full animate-float-slow"
              style={{ animationDelay: "1s" }}
            />
            <div
              className="absolute bottom-1/3 left-1/6 w-1 h-1 bg-primary/70 rounded-full animate-float"
              style={{ animationDelay: "2s" }}
            />
          </div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-6">
            <Image
              src="/79ratio-logo.webp"
              alt="79Ratio Logo"
              width={200}
              height={67}
              className="mx-auto mb-8"
              priority
            />
            <Badge className="mb-4 bg-primary/20 text-primary border-primary/30">Cybersecurity Solutions</Badge>
            <h1 className="text-4xl lg:text-6xl font-bold text-white leading-tight text-balance">
              Advanced <span className="text-primary">Cybersecurity</span> That Protects Your Business
            </h1>
            <p className="text-xl text-gray-200 leading-relaxed text-pretty max-w-3xl mx-auto">
              Stay ahead of evolving cyber threats with our comprehensive, multi-layered security approach designed to
              protect your assets and operations.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="text-lg px-8">
                <Link href="/schedule-call">Schedule a Call</Link>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="text-lg px-8 border-white text-white hover:bg-white hover:text-black bg-transparent"
              >
                <Link href="/contact">Security Assessment</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Protection Against Modern Threats */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Protection Against Modern Threats</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              We defend against the most sophisticated cyber attacks targeting your business today.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {threats.map((threat, index) => {
              const IconComponent = threat.icon
              return (
                <Card
                  key={index}
                  className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300"
                >
                  <CardHeader>
                    <IconComponent className="w-8 h-8 text-primary mb-3" />
                    <CardTitle className="text-lg text-white">{threat.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-gray-300">{threat.description}</CardDescription>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-background/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">Comprehensive Security Services</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Multi-layered protection covering detection, response, and prevention.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {services.map((service, index) => {
              const IconComponent = service.icon
              return (
                <Card
                  key={index}
                  className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/20 transition-all duration-300"
                >
                  <CardHeader>
                    <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center mb-4">
                      <IconComponent className="w-6 h-6 text-primary" />
                    </div>
                    <CardTitle className="text-xl text-white">{service.title}</CardTitle>
                    <CardDescription className="text-gray-400">{service.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-gray-300 text-sm">{service.details}</p>
                    <div className="space-y-2">
                      <p className="text-sm font-semibold text-primary">Benefits:</p>
                      <ul className="space-y-1">
                        {service.benefits.map((benefit, idx) => (
                          <li key={idx} className="text-sm text-gray-300 flex items-center">
                            <span className="w-1.5 h-1.5 bg-primary rounded-full mr-2" />
                            {benefit}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* NIST Framework */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">NIST Cybersecurity Framework</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Our security approach is based on industry-leading NIST standards covering all aspects of cybersecurity.
            </p>
          </div>

          <div className="grid md:grid-cols-5 gap-4">
            {framework.map((item, index) => (
              <div key={index} className="text-center">
                <div className="mb-4">
                  <div className="w-14 h-14 bg-primary/20 text-primary rounded-full flex items-center justify-center mx-auto mb-4 font-semibold text-sm">
                    {index + 1}
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">{item.step}</h3>
                  <p className="text-gray-300 text-sm">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications & Compliance */}
      <section className="py-20 bg-background/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Certifications & Compliance Track Record
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Industry-leading certifications and a perfect compliance record.
            </p>
          </div>

          <div className="grid md:grid-cols-5 gap-6 mb-12">
            {certifications.map((cert, index) => (
              <Card
                key={index}
                className="bg-white/10 backdrop-blur-sm border-white/20 text-center hover:bg-white/20 transition-all duration-300"
              >
                <CardContent className="p-6">
                  <p className="font-semibold text-primary text-lg">{cert}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-8 md:p-12">
            <div className="grid md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-4xl font-bold text-primary mb-2">100%</div>
                <p className="text-gray-300">Compliance Rate</p>
              </div>
              <div>
                <div className="text-4xl font-bold text-primary mb-2">Zero</div>
                <p className="text-gray-300">Data Breaches</p>
              </div>
              <div>
                <div className="text-4xl font-bold text-primary mb-2">24/7</div>
                <p className="text-gray-300">Active Monitoring</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary/10 via-background to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-6">Protect Your Business Today</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Don't wait for a breach. Let our cybersecurity experts assess your current security posture and build a
            comprehensive protection strategy.
          </p>
          <Button asChild size="lg" className="text-lg px-8 bg-primary hover:bg-primary/90">
            <Link href="/schedule-call">
              Schedule a Security Assessment
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  )
}
