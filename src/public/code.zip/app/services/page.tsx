import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Monitor, Shield, Cloud, HardDrive, Headphones, Settings, ArrowRight, CheckCircle } from "lucide-react"
import Link from "next/link"

const services = [
  {
    icon: Monitor,
    title: "24/7/365 Monitoring",
    slug: "monitoring",
    description:
      "Proactive network monitoring and threat detection that keeps your business running smoothly — because your peace of mind matters.",
    features: [
      "Real-time network monitoring",
      "Automated threat detection",
      "Performance optimization",
      "Instant alert notifications",
    ],
    benefits: ["99.9% uptime guarantee", "Reduced downtime costs", "Improved system performance", "Peace of mind"],
    testimonial:
      '"Since Ratio79 started monitoring our systems, we sleep better knowing someone\'s always watching. They caught a potential issue at 2 AM last month — saved us thousands." — IT Manager, Cape Town',
  },
  {
    icon: Shield,
    title: "Cybersecurity & Infrastructure",
    slug: "cybersecurity",
    description:
      "Comprehensive security that protects your digital core, ensuring resilience against any threat — because real people depend on it.",
    features: ["Multi-layered security", "Endpoint protection", "Security awareness training", "Compliance audits"],
    benefits: [
      "Protection from cyber threats",
      "Regulatory compliance",
      "Reduced security risks",
      "Employee education",
    ],
    testimonial:
      '"We faced a ransomware attempt last quarter. Ratio79\'s team not only stopped it, but walked us through each step — we felt safe and informed the entire time." — Client, Cape Town',
  },
  {
    icon: Cloud,
    title: "Integrated Voice & Data",
    slug: "cloud",
    description:
      "Seamless communication that empowers your team to connect effortlessly — because collaboration is people first.",
    features: ["VoIP systems", "Unified communications", "Video conferencing", "Mobile integration"],
    benefits: ["Enhanced collaboration", "Improved productivity", "Cost savings", "Flexible work options"],
    testimonial:
      "\"We're now a global team that actually feels like one office. Ratio79 didn't just upgrade our phones — they gave us connection.\" — IT Manager, Johannesburg",
  },
  {
    icon: HardDrive,
    title: "Managed Office",
    slug: "backup",
    description: "We manage the digital backbone of your workplace so your people can focus on what they do best.",
    features: ["Print management", "Document workflow", "Equipment maintenance", "Supply management"],
    benefits: ["Reduced office stress", "Improved efficiency", "Cost optimization", "Team focus"],
    testimonial:
      '"Before Ratio79, our printers and documents were a constant headache. Now, my team actually enjoys office workflow — who knew that was possible?"',
  },
  {
    icon: Headphones,
    title: "Business Automation",
    slug: "support",
    description:
      "Intelligent automation that eliminates manual tasks, giving your team more time for creativity and impact.",
    features: ["Process automation", "Document capture", "Workflow optimization", "Task elimination"],
    benefits: ["Time savings", "Reduced errors", "Improved focus", "Strategic thinking"],
    testimonial:
      '"The automation system we implemented last month saved our team over 20 hours per week — time we now invest in client strategy and team growth."',
  },
  {
    icon: Settings,
    title: "Physical Security",
    slug: "strategy",
    description: "Advanced physical security that keeps your people, assets, and premises safe.",
    features: ["Video surveillance", "Access control", "Real-time monitoring", "Threat detection"],
    benefits: ["Asset protection", "Employee safety", "Peace of mind", "24/7 visibility"],
    testimonial:
      '"Knowing our employees and equipment are protected 24/7 allows us to focus on our mission instead of worrying about what could go wrong."',
  },
]

export default function ServicesPage() {
  return (
    <main className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="relative py-20 lg:py-32 overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: "url(/services-bg.png)" }}
        />

        {/* Dark Overlay */}
        <div className="absolute inset-0 bg-black/60" />

        {/* Floating Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-2 h-2 bg-primary rounded-full animate-float opacity-60" />
          <div className="absolute top-40 right-20 w-1 h-1 bg-accent rounded-full animate-float-slow opacity-40" />
          <div
            className="absolute bottom-32 left-1/4 w-1.5 h-1.5 bg-primary rounded-full animate-float opacity-50"
            style={{ animationDelay: "1s" }}
          />
          <div
            className="absolute top-1/3 right-1/3 w-1 h-1 bg-accent rounded-full animate-float-slow opacity-30"
            style={{ animationDelay: "2s" }}
          />
          <div
            className="absolute bottom-20 right-10 w-2 h-2 bg-primary rounded-full animate-float opacity-40"
            style={{ animationDelay: "0.5s" }}
          />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-6">
            <h1 className="text-4xl lg:text-6xl font-bold text-white leading-tight text-balance">
              Comprehensive <span className="text-primary">IT Services</span>
            </h1>
            <p className="text-xl text-white/90 max-w-3xl mx-auto leading-relaxed text-pretty">
              From proactive monitoring to strategic planning, we provide the complete IT infrastructure your business
              needs to thrive in today's digital landscape.
            </p>
            <Button asChild size="lg" className="text-lg px-8">
              <Link href="/contact">Schedule Consultation</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const IconComponent = service.icon
              return (
                <Card key={index} className="group hover:shadow-lg transition-all duration-300 border-border bg-card">
                  <CardHeader className="space-y-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                      <IconComponent className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-xl text-card-foreground">{service.title}</CardTitle>
                      <CardDescription className="text-muted-foreground mt-2">{service.description}</CardDescription>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <h4 className="font-medium text-card-foreground mb-3">Key Features:</h4>
                      <ul className="space-y-2">
                        {service.features.slice(0, 3).map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-center text-sm text-muted-foreground">
                            <CheckCircle className="w-4 h-4 text-primary mr-2 flex-shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {service.testimonial && (
                      <div className="bg-muted/50 p-4 rounded-lg border-l-4 border-primary">
                        <p className="text-sm text-muted-foreground italic">{service.testimonial}</p>
                      </div>
                    )}

                    <div className="pt-4">
                      <Button asChild className="w-full">
                        <Link href={`/services/${service.slug}`} className="inline-flex items-center gap-2">
                          Learn More
                          <ArrowRight className="w-4 h-4" />
                        </Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary to-accent">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-6">
            <h2 className="text-3xl lg:text-4xl font-bold text-primary-foreground text-balance">
              Ready to Transform Your IT Infrastructure?
            </h2>
            <p className="text-xl text-primary-foreground/90 text-pretty">
              Let's discuss your specific needs and create a customized IT solution that drives your business forward.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" variant="secondary" className="text-lg px-8">
                <Link href="/contact">Get Free Assessment</Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="text-lg px-8 border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary bg-transparent"
              >
                <Link href="/about">Learn About Us</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
