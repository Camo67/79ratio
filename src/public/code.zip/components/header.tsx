import { Navigation } from "@/components/navigation"

export function Header() {
  return <Navigation />
}
